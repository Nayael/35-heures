// Initialize the game once the window loading is complete
window.onload = function () {
	Game.instance.init();
};