var Globals = (function() {
    'use strict';

    var Globals = {
        CANVAS_WIDTH     : 1280,
        CANVAS_HEIGHT    : 720,
        CANVAS_BACKGROUND: 'rgb(255, 255, 255)',
        IMAGE_PATH       : 'assets/img/',
        AUDIO_PATH       : 'assets/audio/'
    }

    return Globals;

})();
