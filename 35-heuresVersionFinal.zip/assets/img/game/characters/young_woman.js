var young_woman = [{
	"name": "young_woman-idle",
	"x": 0,
	"y": 0,
	"width": 468,
	"height": 490
}, {
	"name": "young_woman-angry",
	"x": 469,
	"y": 0,
	"width": 468,
	"height": 490
}, {
	"name": "young_woman-happy",
	"x": 0,
	"y": 491,
	"width": 468,
	"height": 490
}]